package com.tbhs.b84;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestjpaTrainApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestjpaTrainApplication.class, args);
	}

}
